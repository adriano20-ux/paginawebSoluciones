-- Base de datos de Soluciones Integrales Torres
-- Importar desde phpMyAdmin (pestaña "Importar") o con:
--   C:\xampp\mysql\bin\mysql.exe -u root < soluciones_torres.sql

SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS soluciones_torres
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE soluciones_torres;

DROP TABLE IF EXISTS solicitudes;
DROP TABLE IF EXISTS usuarios;
DROP TABLE IF EXISTS servicios;
DROP TABLE IF EXISTS productos;

-- Usuarios: clientes, trabajador y administrador (la clave se guarda con hash)
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    correo VARCHAR(120) NOT NULL UNIQUE,
    clave VARCHAR(255) NOT NULL,
    rol ENUM('cliente','trabajador','administrador') NOT NULL DEFAULT 'cliente',
    creado DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE servicios (
    nombre VARCHAR(100) PRIMARY KEY,
    precio DECIMAL(10,2) NOT NULL
);

CREATE TABLE productos (
    nombre VARCHAR(100) PRIMARY KEY,
    precio DECIMAL(10,2) NOT NULL
);

CREATE TABLE solicitudes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    tipo ENUM('Servicio','Producto') NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT NOT NULL,
    cantidad INT NOT NULL DEFAULT 1,
    total DECIMAL(10,2) NOT NULL,
    estado ENUM('Pendiente','Asignado','En proceso','Terminado','Entregado') NOT NULL DEFAULT 'Pendiente',
    tecnico VARCHAR(100) NOT NULL DEFAULT '',
    fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

INSERT INTO servicios (nombre, precio) VALUES
    ('Soporte técnico', 80),
    ('Cableado de red', 250),
    ('Instalación de impresoras', 100),
    ('Mantenimiento de computadoras', 120),
    ('Supervisión de GPS', 150);

INSERT INTO productos (nombre, precio) VALUES
    ('Mouse inalámbrico', 25),
    ('Teclado USB', 45),
    ('Cable de red UTP 10m', 15),
    ('Tinta para impresora', 60),
    ('Router WiFi', 120),
    ('Memoria USB 32GB', 30);

-- Cuentas de ejemplo
INSERT INTO usuarios (id, nombre, telefono, correo, clave, rol) VALUES
    (1, 'Administrador', '000000000', 'admin@torres.com', '$2y$10$k5mRxY8jpB6enL183dunleOaFj55Lqlz.3SV1aV1gML/eGT7gY3wK', 'administrador'),
    (2, 'Trabajador', '000000001', 'trabajador@torres.com', '$2y$10$VNVtLCnlxUQyVggeTGcrQeqHdHgIQdFo12mak99/eJGrVP6PpHh8a', 'trabajador'),
    (3, 'Ana Torres', '987654321', 'ana@andina.com', '$2y$10$DL5yd0cV2bP91L7M68EzRut08ngMAWlqMxIIs37OQSMjIcAW2.fsm', 'cliente'),
    (4, 'Pedro Salas', '956123456', 'pedro@salas.com', '$2y$10$DL5yd0cV2bP91L7M68EzRut08ngMAWlqMxIIs37OQSMjIcAW2.fsm', 'cliente'),
    (5, 'Lucía Vega', '945789123', 'lucia@vida.com', '$2y$10$DL5yd0cV2bP91L7M68EzRut08ngMAWlqMxIIs37OQSMjIcAW2.fsm', 'cliente');

-- Solicitudes de ejemplo
INSERT INTO solicitudes (usuario_id, tipo, nombre, descripcion, cantidad, total, estado, tecnico, fecha) VALUES
    (3, 'Servicio', 'Soporte técnico', 'Ejemplo', 1, 80, 'Terminado', 'Carlos Ramos', CONCAT(YEAR(CURDATE()), '-06-04 10:00:00')),
    (4, 'Producto', 'Mouse inalámbrico', '-', 4, 100, 'Entregado', '', CONCAT(YEAR(CURDATE()), '-06-12 10:00:00')),
    (5, 'Servicio', 'Mantenimiento de computadoras', 'Ejemplo', 1, 120, 'Terminado', 'Luis Paredes', CONCAT(YEAR(CURDATE()), '-07-03 10:00:00')),
    (4, 'Servicio', 'Cableado de red', 'Ejemplo', 1, 250, 'Terminado', 'María Quispe', CONCAT(YEAR(CURDATE()), '-07-15 10:00:00')),
    (3, 'Producto', 'Router WiFi', '-', 2, 240, 'Entregado', '', CONCAT(YEAR(CURDATE()), '-08-08 10:00:00')),
    (5, 'Servicio', 'Soporte técnico', 'Ejemplo', 1, 80, 'Terminado', 'Carlos Ramos', CONCAT(YEAR(CURDATE()), '-08-20 10:00:00')),
    (3, 'Servicio', 'Instalación de impresoras', 'Ejemplo', 1, 100, 'Terminado', 'Luis Paredes', CONCAT(YEAR(CURDATE()), '-09-02 10:00:00')),
    (4, 'Servicio', 'Mantenimiento de computadoras', 'Ejemplo', 1, 120, 'Terminado', 'María Quispe', CONCAT(YEAR(CURDATE()), '-09-10 10:00:00')),
    (5, 'Producto', 'Tinta para impresora', '-', 5, 300, 'Entregado', '', CONCAT(YEAR(CURDATE()), '-09-24 10:00:00')),
    (4, 'Servicio', 'Cableado de red', 'Ejemplo', 1, 250, 'Terminado', 'Carlos Ramos', CONCAT(YEAR(CURDATE()), '-10-05 10:00:00')),
    (3, 'Producto', 'Cable de red UTP 10m', '-', 10, 150, 'Entregado', '', CONCAT(YEAR(CURDATE()), '-10-14 10:00:00')),
    (5, 'Servicio', 'Soporte técnico', 'Ejemplo', 1, 80, 'Terminado', 'Luis Paredes', CONCAT(YEAR(CURDATE()), '-10-27 10:00:00'));

-- Solicitudes del mes
INSERT INTO solicitudes (usuario_id, tipo, nombre, descripcion, cantidad, total, estado, tecnico, fecha) VALUES
    (3, 'Servicio', 'Soporte técnico', 'Ejemplo', 1, 80, 'Terminado', 'Carlos Ramos', DATE_FORMAT(CURDATE(), '%Y-%m-01 09:00:00')),
    (4, 'Servicio', 'Mantenimiento de computadoras', 'Ejemplo', 1, 120, 'En proceso', 'Luis Paredes', DATE_FORMAT(CURDATE(), '%Y-%m-02 09:00:00')),
    (5, 'Servicio', 'Cableado de red', 'Ejemplo', 1, 250, 'Asignado', 'María Quispe', DATE_FORMAT(CURDATE(), '%Y-%m-03 09:00:00')),
    (3, 'Servicio', 'Instalación de impresoras', 'Ejemplo', 1, 100, 'Pendiente', '', DATE_FORMAT(CURDATE(), '%Y-%m-04 09:00:00')),
    (4, 'Producto', 'Mouse inalámbrico', '-', 3, 75, 'Entregado', '', DATE_FORMAT(CURDATE(), '%Y-%m-02 09:00:00')),
    (5, 'Producto', 'Router WiFi', '-', 1, 120, 'Pendiente', '', DATE_FORMAT(CURDATE(), '%Y-%m-05 09:00:00'));
